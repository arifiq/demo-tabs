<template>
  <div class="wrapper">
    <scroller class="scroller">
      <div class="row" v-for="(name, index) in rows" :ref="'item'+index" :key="index">
        <text class="text" :ref="'text'+index">{{name}}</text>
      </div>
    </scroller>
  </div>
</template>

<script>
/* eslint-disable */
  const dom = weex.requireModule('dom')

  export default {
    data () {
      return {
        rows: []
      }
    },
    created () {
      for (let i = 0; i < 300; i++) {
        this.rows.push('row ' + i)
      }
    },
  }
</script>

<style scoped>
  .scroller {
    width: 700px;
    /* height: 700px; */
    /* border-width: 3px; */
    /* border-style: solid; */
    /* border-color: rgb(162, 217, 192); */
    margin-left: 25px;
  }
  .row {
    height: 200px;
    flex-direction: column;
    justify-content: center;
    padding-left: 30px;
    /* border-bottom-width: 2px; */
    /* border-bottom-style: solid; */
    /* border-bottom-color: #DDDDDD; */
  }
  .text {
    font-size: 45px;
    color: #666666;
  }
</style>