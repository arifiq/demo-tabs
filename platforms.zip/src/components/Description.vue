<template>
<div class="content">
    <text>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit illo
        perferendis fugiat nobis enim iure dolor beatae ducimus reprehenderit et
        harum consectetur culpa sint nostrum officia, quam distinctio maxime non.
    </text>
</div>
</template>
<script>
export default {
}
</script>
<style scoped>
.content {
    margin: 5px;
    text-align: start;
}
</style>
